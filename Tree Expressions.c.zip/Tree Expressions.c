#include<stdio.h>

#include<ctype.h>

#include <string.h>

#include <stdlib.h>

#include <string.h>

#include <math.h>


char stack[100], out[200];
int top = -1;

typedef struct _node {
   char data[10];
   struct _node * right;
   struct _node * left;
}
node;

void push(char ch);
char pop();
int priority(char ch);
char * unary(char * str);
void topostfix(char * str);
node * build_tree(char * postf, int * i);
void inorder(node * root);
void postorder(node * root);
void preorder(node * root);
float evaluate();
void menu();


int main() {
   char exp[100], e[100], * str;
   int t = strlen(out) - 1, ans;
   node * root = NULL;
   float result;
   do {   
      menu(); 
      printf("\n\n\t\t\tEnter your choice\t>>\t");
      scanf("%d", & ans);
      switch (ans) {
      case 1:
         printf("\n\n\t\t\tEnter the expression : ");
         scanf(" %[^\n]s", exp);
         printf("\n");
         unary(exp);
         topostfix(exp);
         t = strlen(out) - 1;
         root = build_tree(out, & t);
         break;
      case 2:
         printf("\t2. In-Order    / LNR Traversal \t>>\t");
         inorder(root);
         break;
      case 3:
         printf("\t3. Pre-Order    / NLR Traversal \t>>\t");
         preorder(root);
         break;
      case 4:
         printf("\t4. Post-Order    / LRN Traversal  \t>>\t");
         postorder(root);
         break;
      case 5:
         result = evaluate();
         printf("\t5. Compute Expression  \t>>\t%f", result);
         break;
      case 6:

         printf("\t\t\tEXIT\n");
         break;
      default:

         printf(" \t\t %d is not a choice\n", ans);

         break;

      }
   
   } while (ans != 6);
}
void push(char ch) {
   if( top < 99)
   stack[++top] = ch;
   else return;
}

char pop() {
   if (top == -1)
      return -99;
   else
      return stack[top--];
}

int priority(char ch) {
   if (ch == '(')
      return 0;
   if (ch == '+' || ch == '-')
      return 1;
   if (ch == '*' || ch == '/' || ch == '%')
      return 2;
   if (ch == '^')
      return 3;
   return 0;
}

char * unary(char * str) {
   int j;
   for (int i = 0; i < strlen(str); i++) {
      if (str[i] == str[i + 1] && (str[i] == '+' || str[i] == '-')) {
         if (str[i] == '+') {
            str[i] = '>';
            for (j = i + 1; j < strlen(str) - 1; j++)
               str[j] = str[j + 1];
               str[j] = '\0';
            } 
            else if (str[i] == '-') {
            str[i] = '<';
            for (j = i + 1; j < strlen(str) - 1; j++)
               str[j] = str[j + 1];
            str[j] = '\0';
         }
      }
   }
   return str;
}

void topostfix(char * str) {
   char * c = str, x;
   int k = 0;
   while ( * c != '\0') {
      while ( * c == ' ')
         c++;
      if ( * c == ' ') c++;
      if (isalnum( * c) || * c == '>' || * c == '<') {
         if ((isalnum( * c) || * c == '>' || * c == '<') && (isalnum( * (c - 1)) || * (c - 1) == '>' || * (c - 1) == '<')) {
            out[k++] = * c;
         } else {
            out[k++] = ' ';
            out[k++] = * c;
         }
      } else if ( * c == '(')
         push( * c);
      else if ( * c == ')') {
         while ((x = pop()) != '(') {
            out[k++] = ' ';
            out[k++] = x;
         }
      } else {
         while (priority(stack[top]) >= priority( * c)) {
            out[k++] = ' ';
            out[k++] = stack[top];
            pop();

         }
         push( * c);
      }
      c++;
   }

   while (top != -1) {
      out[k++] = ' ';
      out[k++] = stack[top];
      pop();
   }
   out[k] = '\0';
}

node * build_tree(char * postf, int * i) {
   int k = 0;
   node * temp;
   while (postf[ * i] == ' ')
      ( * i) --;
   temp = (node * ) malloc(sizeof(node));
   temp -> data[k] = postf[( * i)];
   if (isalnum(postf[ * i]) || postf[ * i] == '>' || postf[ * i] == '<') {
      while (isalnum(postf[( * i)]) || postf[ * i] == '>' || postf[ * i] == '<') {
         temp -> data[k++] = postf[( * i) --];
      }
      temp -> left = temp -> right = NULL;
      return temp;
   } else {
      while (postf[ * i] == ' ')
         ( * i) --;
      ( * i) --;
      temp -> right = build_tree(postf, i);
      ( * i) --;
      temp -> left = build_tree(postf, i);
      return temp;
   }
}

void inorder(node * root) {
   int i;
   char ch;
   if (root == NULL) {
      return;
   }
   inorder(root -> left);

   for (i = strlen(root -> data); i >= 0; i--) {
      ch = root -> data[i];
      switch (ch) {
      case '>':
         ch = '+';
         printf("+");
         break;
      case '<':
         ch = '-';
         printf("-");
         break;
      }
      printf("%c", ch);
   }
   printf(" ");
   inorder(root -> right);
}
void postorder(node * root) {
   int i;
   char ch;
   if (root == NULL) {
      return;
   }
   postorder(root -> left);
   postorder(root -> right);
   for (i = strlen(root -> data); i >= 0; i--) {
      ch = root -> data[i];
      switch (ch) {
      case '>':
         ch = '+';
         printf("+");
         break;
      case '<':
         ch = '-';
         printf("-");
         break;
      }
      printf("%c", ch);
   }
   printf(" ");
}
void preorder(node * root) {
   int i;
   char ch;
   if (root == NULL) {
      return;
   }
   for (i = strlen(root -> data); i >= 0; i--) {
      ch = root -> data[i];
      switch (ch) {
      case '>':
         ch = '+';
         printf("+");
         break;
      case '<':
         ch = '-';
         printf("-");
         break;
      }
      printf("%c", ch);
   }
   printf(" ");
   preorder(root -> left);
   preorder(root -> right);
}
int evtop = -1; 
float evstack[100];
void evpush(float data){
        evstack[++evtop] = data;
}
float evpop()
{
    float data;
        data = evstack[evtop];
        evtop--;
        return data;
}

float evaluate(){
  float result, a, b, c;
  char str[100];
  strcpy(str, out);
  for( int i = 0; i < strlen( str); i++){
    while( str[i] == ' ') i++;
    if( str[i] <= 57 && str[i] >= 48){
      c = (float)(str[i]) - 48;
      evpush(c);
    }
    else{
      a = evpop();
      b = evpop();
      switch( str[i]){
        case '+':
          result = b + a;
          break;
        case '-':
          result = b - a;
          break;
        case '*':
          result = b * a;
          break;
        case '/':
          result = b / a;
          break;
        case '%':
          result = (int)b % (int)a;
          break; 
        case '>':
          result = a + 1;
          break;
        case '<':
          result = a - 1;
          break;
        case '^':
          result = pow(b,a);
          break;
          default:break;
      }
      evpush(result);
    }
  }
  result = evpop();
  return result; 
}
void menu() {
   printf("\n\nMENU\n\n");
   
   printf("\t1. Enter In-order Expression                             ");
   printf("\t2. In-Order  LNR Traversal                             \n");
   printf("\t3. Pre-Order  NLR Traversal                            \n");
   printf("\t4. Post-Order  LRN Traversal                           \n");
   printf("\t5. Compute Expression                                    ");
   printf("\t6. Quit                                                  \n");
   
}
